package com.simplecity.amp_library.di.app.activity.fragment

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class FragmentScope