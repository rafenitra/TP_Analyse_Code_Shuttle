package com.simplecity.amp_library.http.lastfm;

public interface LastFmResult {

    String getImageUrl();
}
