package com.simplecity.amp_library.ui.common;

import android.support.v7.widget.Toolbar;

//Todo: Better name
public interface ToolbarListener {
    void toolbarAttached(Toolbar toolbar);
}
