package com.simplecity.amp_library.ui.views;

public interface PurchaseView {

    void showUpgradeDialog();
}