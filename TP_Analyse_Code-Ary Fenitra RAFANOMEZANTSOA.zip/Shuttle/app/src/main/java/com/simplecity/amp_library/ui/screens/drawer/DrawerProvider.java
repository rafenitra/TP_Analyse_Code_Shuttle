package com.simplecity.amp_library.ui.screens.drawer;

import android.support.v4.widget.DrawerLayout;

public interface DrawerProvider {

    DrawerLayout getDrawerLayout();
}