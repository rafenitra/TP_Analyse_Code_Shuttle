package com.simplecity.amp_library.playback.constants;

public interface ShortcutCommands {
    String PLAY = "com.simplecity.amp_library.shortcuts.PLAY";
    String SHUFFLE_ALL = "com.simplecity.amp_library.shortcuts.SHUFFLE";
    String FOLDERS = "com.simplecity.amp_library.shortcuts.FOLDERS";
    String PLAYLIST = "com.simplecity.amp_library.shortcuts.PLAYLIST";
}
