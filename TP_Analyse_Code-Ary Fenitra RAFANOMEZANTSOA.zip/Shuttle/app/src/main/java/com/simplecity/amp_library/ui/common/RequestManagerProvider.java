package com.simplecity.amp_library.ui.common;

import com.bumptech.glide.RequestManager;

public interface RequestManagerProvider {

    RequestManager getRequestManager();
}
