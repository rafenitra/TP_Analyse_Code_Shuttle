package com.simplecity.amp_library.ui.modelviews;

public interface SelectableViewModel {

    void setSelected(boolean selected);

    boolean isSelected();
}