package com.simplecity.amp_library.ui.views;

public interface ContextualToolbarHost {

    ContextualToolbar getContextualToolbar();
}