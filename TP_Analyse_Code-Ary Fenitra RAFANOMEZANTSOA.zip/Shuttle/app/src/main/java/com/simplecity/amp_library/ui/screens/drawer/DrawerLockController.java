package com.simplecity.amp_library.ui.screens.drawer;

public interface DrawerLockController {

    void lockDrawer();

    void unlockDrawer();
}