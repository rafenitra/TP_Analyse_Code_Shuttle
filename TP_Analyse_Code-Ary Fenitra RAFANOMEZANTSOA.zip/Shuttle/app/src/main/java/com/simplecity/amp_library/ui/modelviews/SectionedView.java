package com.simplecity.amp_library.ui.modelviews;

public interface SectionedView {

    String getSectionName();
}
